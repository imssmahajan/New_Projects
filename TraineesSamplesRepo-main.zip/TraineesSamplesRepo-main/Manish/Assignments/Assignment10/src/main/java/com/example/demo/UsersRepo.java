package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface UsersRepo extends CrudRepository<Users, Integer>{

}
