package com.example.demo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Delete {

	@RequestMapping("/delete")
	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String id = request.getParameter("id");
	    try {
			Connection con = ConnectionProvider.getCon();
			Statement st = con.createStatement();
			st.executeUpdate("delete from users where id=" + id);
			System.out.println("DELETED record with ID: "+ id);
			response.sendRedirect("fetch.jsp?id="+id+"&flag=yes");
			con.close();
		} catch (Exception e) {
			System.out.println("Error deleting record");
			e.printStackTrace();
			response.sendRedirect("fetch.jsp?id="+id+"&flag=no");
			System.out.println(e);
		}	
	}
}
