var gender = document.getElementsByName("gender");
var interests = document.getElementsByName("interests");
var age = document.getElementById("age");

//Setting attributes for age
age.setAttribute("maxlength", "3");
age.setAttribute("oninput", "ageSlice(this)");

//Setting Maxlength slicing for age input
function ageSlice(age) {
  if (age.value.length > age.maxLength)
    age.value = age.value.slice(0, age.maxLength);
}

//Setting onClick event for gender input
for (let i = 0; i < gender.length; i++) {
  gender[i].setAttribute("onclick", "radioSelect()");
}

//Setting onClick event for interests input
for (let i = 0; i < interests.length; i++) {
  interests[i].setAttribute("onchange", "checkSelect(this)");
}

var gVal; // variable to store Gender value
let SkillVal = []; // variable to store interests values

//Function to get selected radio value
function radioSelect() {
  for (let i = 0; i < gender.length; i++) {
    if (gender[i].checked) gVal = gender[i].value;
  }
  console.log("gender: " + gVal);
}

//Function to get selected checkboxes value
function checkSelect(checkbox) {
  if (checkbox.checked == true) {
    SkillVal.push(checkbox.value);
  } else {
    var temp = SkillVal.indexOf(checkbox.value);
    SkillVal.splice(temp, 1);
  }
  console.log("interests: " + SkillVal);
}

function submitForm() {
  //Getting All form elements
  var Name = document.getElementById("name");
  var email = document.getElementById("email");
  var age = document.getElementById("age");

  var submitValue = true;

  //Alert Function for invalid name pattern
  if (Name.value.length === 0) {
    alert("Name cannot be empty");
    Name.focus();
    submitValue = false;
  }

  if (submitValue) {
    if (Name.value.length < 3) {
      alert("Name must contain minimum 3 characters");
      Name.focus();
      submitValue = false;
    }
  }

  if (submitValue) {
    if (!Name.value.match(/^[a-zA-Z\s]*$/)) {
      alert("Name must contain only alageabets A-Z");
      Name.focus();
      submitValue = false;
    }
  }

  //Alert Function for invalid email pattern
  if (submitValue) {
    if (email.value.length === 0) {
      alert("Email cannot be empty");
      email.focus();
      submitValue = false;
    }
  }

  if (submitValue) {
    if (!email.value.match(/^([a-zA-z0-9.]+[@][a-zA-Z]+[.][a-zA-Z]{2,})$/)) {
      alert("Please enter a valid Email");
      email.focus();
      submitValue = false;
    }
  }

  //Alert Function for invalid age pattern
  if (submitValue) {
    if (age.value.length === 0) {
      alert("age cannot be empty");
      age.focus();
      submitValue = false;
    }
  }

  //Alert Function for no gender checked
  if (submitValue) {
    if (gVal == "" || gVal == null) {
      alert("Please select gender");
      submitValue = false;
    }
  }

  //Alert Function for no checkboxes checked
  if (submitValue) {
    if (SkillVal == "" || SkillVal == null) {
      alert("Please select atleast 1 interest");
      submitValue = false;
    }
  }

  //Function to display alert on submitting form with enetered data
  if (submitValue) {
    var details =
      "Name: " +
      Name.value +
      ";\n" +
      "Age: " +
      age.value +
      ";\n" +
      "Email: " +
      email.value +
      ";\n" +
      "Gender: " +
      gVal +
      ";\n" +
      "interests: " +
      SkillVal +
      ";\n";
    alert(details);
  }
  localStorage.setItem("form-details", details);
  return submitValue;
}

function displayDetails() {
  var thankyou = document.getElementById("thankyou");
  thankyou.innerHTML += "<h3>" + localStorage.getItem("form-details") + "</h3>";
}
