package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Home {
    @GetMapping("/Manish_Ass10")
    public ModelAndView home() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("register.jsp");
        return mv;
    }
    
    @GetMapping("/data")
    public ModelAndView data() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("fetch.jsp");
        return mv;
    }
}