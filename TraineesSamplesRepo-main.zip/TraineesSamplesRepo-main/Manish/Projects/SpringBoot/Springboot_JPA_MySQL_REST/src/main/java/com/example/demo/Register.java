package com.example.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@SuppressWarnings("all")
@Controller
public class Register {

	@RequestMapping("/register")
	public void register(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("Name");
		String email = request.getParameter("email");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String state = request.getParameter("state");
		String[] interests = request.getParameterValues("interests");
		String myInterests = "";
		for (String s : interests) {
			myInterests = myInterests + s + ",";
		}
		try {
			Connection con = ConnectionProvider.getCon();
			PreparedStatement st = con.prepareStatement("insert into users values(?,?,?,?,?,?,?)");
			st.setInt(1, id);
			st.setString(2, name);
			st.setString(3, email);
			st.setString(4, age);
			st.setString(5, gender);
			st.setString(6, myInterests);
			st.setString(7, state);
			int i = st.executeUpdate();
			System.out.print("Added " + i + " records with values: " + id + " : " + name + " : " + age + " : "
					+ gender + " : " + state + " : ");
			for (String string : interests) {
				System.out.print(string + ", ");
			}
			response.sendRedirect("register.jsp?msg=valid");
			con.close();
		} catch (Exception e) {
			System.out.println("Error adding record");
			e.printStackTrace();
			response.sendRedirect("register.jsp?msg=invalid");
			System.out.println(e);
		}
	}

}
