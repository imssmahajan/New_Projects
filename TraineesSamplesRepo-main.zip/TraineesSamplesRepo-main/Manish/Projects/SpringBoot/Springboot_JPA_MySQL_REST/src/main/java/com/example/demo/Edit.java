package com.example.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Edit {

	@RequestMapping("/edit")
	public void edit(HttpServletResponse response, HttpServletRequest request) throws IOException {
		String id = request.getParameter("id");
		String name = request.getParameter("Name");
		String email = request.getParameter("email");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String state = request.getParameter("state");
		String[] interests = request.getParameterValues("interests");
		String myInterests = "";
		for (String s : interests) {
			myInterests = myInterests + s + ",";
		}

		try {
			Connection con = ConnectionProvider.getCon();
			Statement st = con.createStatement();
			st.executeUpdate("update users set name='" + name + "' , email='" + email + "' , age='" + age
					+ "' , gender='" + gender + "' , interests='" + myInterests+ "' , state='" + state + "' where id='" + id + "'");
			System.out.println("UPDATED record with ID: "+ id);
			System.out.println("New values are: "+id+" : "+name+" : "+age+" : "+gender+" : "+state+" : "+interests);
			response.sendRedirect("edit.jsp?id="+id+"&flag=yes");
			con.close();
		} catch (Exception e) {
			System.out.println("Error updating record");
			e.printStackTrace();
			response.sendRedirect("edit.jsp?id="+id+"&flag=no");
			System.out.println(e);
		}
	}
}
