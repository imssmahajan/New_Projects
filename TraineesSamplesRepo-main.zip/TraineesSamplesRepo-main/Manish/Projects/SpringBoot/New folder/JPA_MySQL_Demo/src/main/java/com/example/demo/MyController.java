package com.example.demo;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class MyController {

	@Autowired
	UsersRepo repo;

	@RequestMapping("/")
	public ModelAndView home() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("register.jsp");
		return mv;
	}

	@RequestMapping("/addUser")
	public ModelAndView addUser(Users users, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("register.jsp");

		try {
			repo.save(users);
			repo.findAll().toString();
			response.sendRedirect("register.jsp?msg=valid");
		} catch (Exception e) {
			response.sendRedirect("register.jsp?msg=invalid");
			System.out.println(e);
		}
		return mv;
	}

	@GetMapping("/users")
	@ResponseBody
	public List<Users> getUsers() {
		return (List<Users>) repo.findAll();
	}

	@GetMapping("/users/{uid}")
	@ResponseBody
	public Optional<Users> getUserByID(@PathVariable("uid") int uid) {
		return repo.findById(uid);
	}

	@PostMapping("/users")
	@ResponseBody
	public Users insertUser(@RequestBody Users users) {
		repo.save(users);
		return users;
	}

	@DeleteMapping("/users/{uid}")
	public Users deleteUser(@PathVariable("uid") int uid) {
		repo.deleteById(uid);
		return new Users();
	}
	
	@PutMapping(path="/users", consumes = {"application/json"})
	public Users updateUser(@RequestBody Users users) {
		repo.save(users);
		return users;
	}
}
