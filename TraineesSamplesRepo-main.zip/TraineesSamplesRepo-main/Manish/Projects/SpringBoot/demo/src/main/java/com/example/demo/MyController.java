package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@Autowired
	UsersRepo repo;

	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}

	@RequestMapping("/addUser")
	public String addUser(Users users) {
		repo.save(users);
		return "home.jsp";
	}

	@RequestMapping("/getUser")
	public ModelAndView getUser(@RequestParam("uid") int id) {
		ModelAndView mv = new ModelAndView("display.jsp");
		Users users = repo.findById(id).orElse(new Users());
		mv.addObject(users);
		return mv;
	}
}
