package com.oops;

interface Parent {
    void eat();

    void sleep();

    void walk();
}

class Child1 implements Parent {

    @Override
    public void eat() {

    }

    @Override
    public void sleep() {

    }

    @Override
    public void walk() {

    }

}

public class ParentRef_ChildRef {
    public static void main(String[] args) {

    }
}
