package com.examples;

public class loops {
    public static void main(String[] args) {

        // for loop
        for (int i = 0; i < 10; i++) {
            System.out.println(i);
        }

        // while loop
        int j = 0;
        while (j < 10) {
            System.out.println(j);
            j++;
        }

        // do while loop
        int k = 0;
        do {
            System.out.println(k);
            k++;
        } while (k < 10);
    }
}
