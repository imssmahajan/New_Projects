package com.examples;

public class Variables {
    public static void main(String[] args) {
        int num1;
        num1 = 10;
        System.out.println("num1: " + num1);
    }
}
