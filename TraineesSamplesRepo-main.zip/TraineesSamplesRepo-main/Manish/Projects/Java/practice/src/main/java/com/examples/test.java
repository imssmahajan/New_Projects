package com.examples;

public class test {
    public static void main(String[] args) {
        int arr[] = new int[10];

        arr[0] = Integer.parseInt(args[0]);
        arr[1] = Integer.parseInt(args[1]);

        for (int i : arr) {
            System.out.println(i);
        }
    }

}
