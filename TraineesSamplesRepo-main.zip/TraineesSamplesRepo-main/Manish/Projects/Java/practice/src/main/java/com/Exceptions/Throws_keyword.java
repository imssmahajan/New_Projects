package com.exceptions;

public class Throws_keyword {
    public static void main(String[] args) throws ClassNotFoundException {
        throw new ClassNotFoundException();
    }
}
