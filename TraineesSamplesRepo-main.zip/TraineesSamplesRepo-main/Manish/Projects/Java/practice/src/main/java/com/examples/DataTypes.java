package com.examples;

public class DataTypes {
    public static void main(String[] args) {
        int num1 = 999999999;
        float num2 = 20424.24943f;
        long num3 = 999999999;
        double num4 = 5324124.6786d;
        String name = "Manish";
        char alp = 'A';
        boolean flag = true;
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(num3);
        System.out.println(num4);
        System.out.println(name);
        System.out.println(alp);
        System.out.println(flag);

    }
}
