package com.examples;

public class switches {
    public static void main(String[] args) {
        int num = 2;
        switch (num) {
            case 0:
                System.out.println("zero");
                break;
            case 1:
                System.out.println("one");
                break;
            case 2:
                System.out.println("two");
                break;
            default:
                System.out.println(" greater than 2");
        }
    }
}
