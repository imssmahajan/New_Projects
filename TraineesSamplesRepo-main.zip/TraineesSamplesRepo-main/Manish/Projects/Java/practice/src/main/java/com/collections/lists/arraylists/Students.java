package com.collections.lists.arraylists;

public class Students {
    int id;
    String name;
    float marks;

    public Students(int id, String name, float marks) {
        this.id = id;
        this.name = name;
        this.marks = marks;
    }

}
