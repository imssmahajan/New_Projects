package com.example.PrimaryBean;

import org.springframework.stereotype.Component;

@Component
public interface Processor {
	void process();
}
