package com.example.PrimaryBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Samsung {
	
	@Autowired
	@Qualifier("intel")
	Processor processor;
	
	void config() {
		System.out.println("12GB + 256GB");
		processor.process();
	}
	
}
