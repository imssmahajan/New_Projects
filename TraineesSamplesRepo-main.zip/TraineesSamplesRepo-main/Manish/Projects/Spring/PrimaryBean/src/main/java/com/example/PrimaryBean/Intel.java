package com.example.PrimaryBean;

import org.springframework.stereotype.Component;

@Component
public class Intel implements Processor{

	@Override
	public void process() {
		System.out.println("Intel is processing");
	}

}
