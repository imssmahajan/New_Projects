package com.example.PrimaryBean;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class AMD implements Processor{

	@Override
	public void process() {
		System.out.println("AMD is processing");
	}

}
