package com.example.JavaConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Samsung {
	
	@Autowired
	Processor processor;
	
	void config() {
		System.out.println("12GB + 256GB");
		processor.process();
	}
	
}
