package com.example.AnnotationConfiguration;

public interface Vehicle {
	void start();
}
