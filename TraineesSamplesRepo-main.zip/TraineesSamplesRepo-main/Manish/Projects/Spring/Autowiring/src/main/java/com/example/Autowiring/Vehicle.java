package com.example.Autowiring;

public interface Vehicle {
	void start();
}
