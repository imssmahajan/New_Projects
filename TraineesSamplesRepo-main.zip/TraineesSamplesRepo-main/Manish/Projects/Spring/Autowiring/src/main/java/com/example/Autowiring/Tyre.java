package com.example.Autowiring;

import org.springframework.stereotype.Component;

@Component
public class Tyre {

	@Override
	public String toString() {
		return "Tyre is working";
	}
}
