package com.example.ApplicationContext;

public interface Vehicle {
	void start();
}
