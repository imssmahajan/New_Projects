package com.example.BeanProperty;

public interface Vehicle {
	void start();
}
