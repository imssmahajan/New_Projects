package com.example.Constructor_BeanProperty;

import org.springframework.stereotype.Component;

@Component
public class Tyre {
	String brand;

	public Tyre(String brand) {
		super();
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Tyre [brand=" + brand + "]";
	}
}
