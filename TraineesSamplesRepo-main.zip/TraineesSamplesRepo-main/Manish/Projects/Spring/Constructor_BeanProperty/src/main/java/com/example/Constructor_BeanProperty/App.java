package com.example.Constructor_BeanProperty;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SuppressWarnings("all")
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Tyre tyre = (Tyre) context.getBean("tyre");
		System.out.println(tyre);
	}
}
