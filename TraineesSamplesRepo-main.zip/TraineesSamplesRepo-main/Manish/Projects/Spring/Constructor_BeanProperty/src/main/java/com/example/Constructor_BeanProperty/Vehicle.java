package com.example.Constructor_BeanProperty;

public interface Vehicle {
	void start();
}
